const mongoose = require('mongoose');


//creating the database 
const db = ('mongodb+srv://chandansharma575757:CPCCMb4FK2jTKWFQ@cluster0.qkm80jw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
mongoose.connect(db,{

}).then(()=> {
    console.log("connected to database");
}).catch((error) => {
    console.log("failed to connect databas",error)
})

module.exports = db;
